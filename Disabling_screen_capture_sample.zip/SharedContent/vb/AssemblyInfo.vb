Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

<Assembly:AssemblyTitle("SDKTemplate")>
<Assembly:AssemblyDescription("")>
<Assembly:AssemblyConfiguration("")>
<Assembly:AssemblyCompany("")>
<Assembly:AssemblyProduct("SDKTemplate")>
<Assembly:AssemblyCopyright("Copyright ©  2014")>
<Assembly:AssemblyTrademark("")>
<Assembly:AssemblyCulture("")>
<Assembly:AssemblyVersion("1.0.0.0")>
<Assembly:AssemblyFileVersion("1.0.0.0")>
<Assembly:ComVisible(False)>
